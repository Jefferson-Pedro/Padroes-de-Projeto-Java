public enum Transmission{
  MANUAL, AUTOMATIC, SEMI_AUTOMATIC;
}