package main;

import controller.ProjectController;
import java.util.List;
import model.Project;

public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    
        
    }
    
}
